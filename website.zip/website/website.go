package main

import (
	"fmt"
	"net/http"
	"html/template"
)

type PageData struct {
	Title       string
	Message     string
	Destinations []string
	Modes       []string
	Ticket      *TicketData
}

type TicketData struct {
	From   string
	To     string
	Mode   string
	Date   string
	Cost   float64
}

func calculateCost(from, to, mode string) float64 {
	distance := map[string]map[string]float64{
		"Delhi":       {"Mumbai": 1400, "Kolkata": 1500, "Chennai": 2200, "Bangalore": 2100},
		"Mumbai":      {"Delhi": 1400, "Kolkata": 1650, "Chennai": 1330, "Bangalore": 980},
		"Kolkata":     {"Delhi": 1500, "Mumbai": 1650, "Chennai": 1700, "Bangalore": 1870},
		"Chennai":     {"Delhi": 2200, "Mumbai": 1330, "Kolkata": 1700, "Bangalore": 350},
		"Bangalore":   {"Delhi": 2100, "Mumbai": 980, "Kolkata": 1870, "Chennai": 350},
	}
	modeMultiplier := map[string]float64{"Flight": 5.3, "Train": 2.5, "Bus": 1.8}

	if dist, exists := distance[from][to]; exists {
		if multiplier, ok := modeMultiplier[mode]; ok {
			return dist * multiplier
		}
	}
	return 0
}

func bookingHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		from := r.FormValue("from")
		to := r.FormValue("to")
		mode := r.FormValue("mode")
		date := r.FormValue("date")
		cost := calculateCost(from, to, mode)

		tmpl := template.Must(template.ParseFiles("ticket.html"))
		data := TicketData{
			From: from, To: to, Mode: mode, Date: date, Cost: cost,
		}
		tmpl.Execute(w, data)
		return
	}
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func handler(w http.ResponseWriter, r *http.Request) {
	tmpl := template.Must(template.ParseFiles("index.html"))
	data := PageData{
		Title:       "Book Your Ticket",
		Message:     "Welcome to the online ticket booking system!",
		Destinations: []string{"Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore"},
		Modes:       []string{"Flight", "Train", "Bus"},
	}
	tmpl.Execute(w, data)
}

func main() {
	http.HandleFunc("/", handler)
	http.HandleFunc("/book", bookingHandler)
	http.HandleFunc("/ticket", bookingHandler) 
	fmt.Println("Server starting on http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
